<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package Dark_Theme_Simplicity
 */

// Check if widgets should be displayed
$show_widgets = 'yes'; // Default to yes

if (is_single()) {
    // Get post-specific setting
    $post_show_widgets = get_post_meta(get_the_ID(), '_show_sidebar_widgets', true);
    
    // Get default from theme customizer
    $default_show_widgets = get_theme_mod('dark_theme_simplicity_default_show_widgets', 'yes');
    
    // Use post-specific setting if available, otherwise use default
    $show_widgets = ($post_show_widgets !== '') ? $post_show_widgets : $default_show_widgets;
} elseif (is_page()) {
    // Get page-specific setting
    $page_show_widgets = get_post_meta(get_the_ID(), '_show_sidebar_widgets', true);
    
    // Get default from theme customizer
    $default_show_widgets = get_theme_mod('dark_theme_simplicity_default_show_widgets', 'yes');
    
    // Use page-specific setting if available, otherwise use default
    $show_widgets = ($page_show_widgets !== '') ? $page_show_widgets : $default_show_widgets;
}

// We're already inside a conditional in single.php, so show widgets if sidebar is active
if (is_single()) {
    if (is_active_sidebar('sidebar-post')) {
        ?>
        <aside id="secondary" class="widget-area bg-dark-400 p-6 rounded-lg border border-white/10 shadow-lg">
            <?php dynamic_sidebar('sidebar-post'); ?>
        </aside>
        <?php
    } elseif (is_active_sidebar('sidebar-1')) {
        ?>
        <aside id="secondary" class="widget-area bg-dark-400 p-6 rounded-lg border border-white/10 shadow-lg">
            <?php dynamic_sidebar('sidebar-1'); ?>
        </aside>
        <?php
    } else {
        // If no widgets are active but show_widgets is yes, display a placeholder
        ?>
        <aside id="secondary" class="widget-area bg-dark-400 p-6 rounded-lg border border-white/10 shadow-lg">
            <div class="widget">
                <h2 class="widget-title">Widget Area</h2>
                <p>This is a widget area. Add widgets in the WordPress admin dashboard.</p>
            </div>
        </aside>
        <?php
    }
} elseif (is_page()) {
    if (is_active_sidebar('sidebar-page')) {
        // Page sidebar
        ?>
        <aside id="secondary" class="widget-area bg-dark-400 p-6 rounded-lg border border-white/10 shadow-lg">
            <?php dynamic_sidebar('sidebar-page'); ?>
        </aside>
        <?php
    } elseif (is_active_sidebar('sidebar-1')) {
        // Default sidebar as fallback for pages
        ?>
        <aside id="secondary" class="widget-area bg-dark-400 p-6 rounded-lg border border-white/10 shadow-lg">
            <?php dynamic_sidebar('sidebar-1'); ?>
        </aside>
        <?php
    } else {
        // If no widgets are active but show_widgets is yes, display a placeholder
        ?>
        <aside id="secondary" class="widget-area bg-dark-400 p-6 rounded-lg border border-white/10 shadow-lg">
            <div class="widget">
                <h2 class="widget-title">Widget Area</h2>
                <p>This is a widget area. Add widgets in the WordPress admin dashboard.</p>
            </div>
        </aside>
        <?php
    }
} else {
    // For other page types
    if (is_active_sidebar('sidebar-1')) {
        ?>
        <aside id="secondary" class="widget-area bg-dark-400 p-6 rounded-lg border border-white/10 shadow-lg">
            <?php dynamic_sidebar('sidebar-1'); ?>
        </aside>
        <?php
    } else {
        // If no widgets are active, display a placeholder
        ?>
        <aside id="secondary" class="widget-area bg-dark-400 p-6 rounded-lg border border-white/10 shadow-lg">
            <div class="widget">
                <h2 class="widget-title">Widget Area</h2>
                <p>This is a widget area. Add widgets in the WordPress admin dashboard.</p>
            </div>
        </aside>
        <?php
    }
} 