<?php get_header(); ?>

<main id="content" class="site-main pt-0 pb-16">
    <div class="container mx-auto px-4" style="margin-top: 2rem;">
        <div class="max-w-6xl mx-auto">
            <?php while (have_posts()) : the_post(); 
                // Get widget display option
                $show_widgets = get_post_meta(get_the_ID(), '_show_sidebar_widgets', true);
                
                // Get default setting from theme customizer
                $default_show_widgets = get_theme_mod('dark_theme_simplicity_default_show_widgets', 'yes');
                
                // Use default if not set on individual page
                if ($show_widgets === '') $show_widgets = $default_show_widgets;
                
                // Set class based on sidebar visibility
                $sidebar_class = ($show_widgets === 'yes') ? '' : 'no-sidebar';
                
                // Calculate responsive content width class - matching single.php
                $content_width_class = 'md:w-4/5 lg:w-4/5 xl:w-5/6'; // Wider default content on larger screens
                
                // If sidebar is hidden, use full width with max-width constraint
                if ($show_widgets !== 'yes') {
                    $content_width_class = 'md:w-full lg:w-full xl:w-full max-w-5xl mx-auto';
                }
                
                // Calculate sidebar width class - narrower on larger screens
                $sidebar_width_class = 'md:w-1/5 lg:w-1/5 xl:w-1/6';
            ?>
                <article <?php post_class('bg-dark-300 rounded-xl shadow-xl overflow-hidden ' . $sidebar_class); ?>>
                    <div class="p-8 md:p-12">
                        <header class="entry-header mb-10">
                            <?php if (has_post_thumbnail()) : ?>
                                <div class="page-thumbnail mb-10">
                                    <?php the_post_thumbnail('large', ['class' => 'w-full h-auto rounded-lg']); ?>
                                </div>
                            <?php endif; ?>

                            <h1 class="entry-title text-3xl md:text-4xl font-bold mb-8 text-white">
                                <?php the_title(); ?>
                            </h1>
                        </header>

                        <!-- Layout for content and widgets using flex instead of grid -->
                        <div class="flex flex-col md:flex-row gap-8">
                            <!-- Main content column -->
                            <div class="flex-1 <?php echo $content_width_class; ?>">
                                <div class="entry-content prose prose-invert prose-lg max-w-none text-light-100/80 prose-p:leading-relaxed prose-headings:mt-8 prose-headings:mb-4">
                                    <?php the_content(); ?>
                                </div>

                                <?php
                                // If comments are open or we have at least one comment, load up the comment template
                                if (comments_open() || get_comments_number()) :
                                    echo '<div class="mt-12">';
                                    comments_template();
                                    echo '</div>';
                                endif;
                                ?>
                            </div>
                            
                            <!-- Sidebar widgets column -->
                            <?php if ($show_widgets === 'yes') : ?>
                                <div class="hidden md:block <?php echo $sidebar_width_class; ?> flex-shrink-0">
                                    <div class="sticky top-24 space-y-4">
                                        <?php get_sidebar(); ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </article>
            <?php endwhile; ?>
        </div>
    </div>
</main>

<?php get_footer(); ?> 